var http = require('http');
var fs = require('fs');

function getFileRoute(res, path, contentType, resCode) {
    if(!resCode) {resCode = 200;}
    fs.readFile(__dirname + path, function(err, data) {
        if (err){
            res.writeHead(500, {'Content-Type': 'text/plain'});
            res.end("500 - Internal Error");
        }
        else {
            res.writeHead(resCode, {'Content-Type': contentType});
            res.end(data);
        }
    })
}

http.createServer(function(req, res) {
    var path = req.url.replace(/\/?(?:\?.*)?$/, '').toLowerCase();
    switch(path){
        
        //route for Main index page and files

        case '':
            getFileRoute(res, "/index.html", "text/html");
            break;
        
        case '/img/welcome.jpg':
            getFileRoute(res, '/img/welcome.jpg', 'image/jpeg');
            break;
        
        //route for about page & it's files

        case '/about':
            getFileRoute(res, '/about.html', 'text/html');
            break;
        
        case '/img/about.jpg':
            getFileRoute(res, '/img/about.jpg', 'image/jpeg');
            break;

        //route for graduation.jpg
        
        case '/img/gallery/graduation':
            getFileRoute(res, '/img/gallery/graduation.jpg', 'image/jpeg');
            break;

        //route for study.jpg
        
        case '/img/gallery/study':
            getFileRoute(res, '/img/gallery/study.jpg', 'image/jpeg');
            break;

        //route for video meme
        
        case '/video/memes.mp4':
            getFileRoute(res, '/video/students/memes.mp4', 'MPEG-4');
            break;

        //route for css file

        case '/style.css':
            getFileRoute(res, '/style.css', 'text/css');
            break;

        //routes for eror page

        case '/img/cry.jpg':
            getFileRoute(res, '/img/cry.jpg', 'image/jpeg');
            break;
        default:
            getFileRoute(res, '/error.html', 'text/html');
            break;
    }
}).listen(3000);
console.log("Runnging localhost on port:3000, Press CTRL+C to exit")